var objectId = require('mongodb').ObjectId;
const db = require('../../model/db.js')
var URL = require('url')
var sd = require('silly-datetime')

exports.getMenuList = (req, res, next) => {
    var params = req.body || req.query
    var where = {}
    where.limit = params.limit ? params.limit : 4
    where.skip = 4 * ((params.limit ? params.limit : 1) - 1)
    console.log(where)
    db.find('menu', where, (err, results) => {
      if (err) {
        res.send('err')
      } else {
        res.send(results)
      }
    })
}

exports.getMenu = (req, res, next) => {
    var params = req.body || req.query
    db.findOneById('article', params.id, (err, results) => {
      if (err) {
        res.send('err')
      } else {
        res.send(results)
      }
    })
}

exports.updateMenu = (req, res, next) => {
    var params = req.body || req.query
    var upObj = {}
    upObj.name = params.name
    upObj.url = params.url
    upObj.pid = params.pid
    upObj.icon = params.icon
    upObj.sort = params.sort
    db.updateOneById('menu', params.id, upObj, (err, results) => {
      if (err) {
        res.send('err')
      } else {
        res.send(results)
      }
    })
}

exports.insertMenu = (req, res, next) => {
    var params = req.body || req.query
    db.insertOne('menu', params, (err, results) => {
      if (err) {
        res.send('err')
      } else {
        res.send(results)
      }
    })
}