var articleController = require('./article')
var Utils = require('./utils')

exports.getArticles = articleController.getArticles
exports.getDetail = articleController.getDetail
exports.getComment = articleController.getComment
exports.updateArticle = articleController.updateArticle
exports.insertArticle = articleController.insertArticle

// 文件上传
exports.utilSingle = Utils.utilSingle
exports.utilSingleRes = Utils.utilSingleRes
exports.utilMulterFile = Utils.utilMulterFile
exports.utilMulterFileRes = Utils.utilMulterFileRes
