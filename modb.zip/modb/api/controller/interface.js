var express = require('express')
const myrouter = require('./router.js')
var router = express.Router()
// 获取文章
router.get('/getArticles', myrouter.getArticles)
router.get('/getDetail', myrouter.getDetail)
router.get('/getComment', myrouter.getComment)
router.post('/getArticles', myrouter.getArticles)
router.post('/getDetail', myrouter.getDetail)
router.post('/getComment', myrouter.getComment)
router.get('/updateArticle', myrouter.updateArticle)
router.post('/updateArticle', myrouter.updateArticle)
router.get('/insertArticle', myrouter.insertArticle)
router.post('/insertArticle', myrouter.insertArticle)

router.get('/utilSingle', myrouter.utilSingle, myrouter.utilSingleRes)
router.get('/utilMulterFile', myrouter.utilMulterFile, myrouter.utilMulterFileRes)
router.post('/utilSingle', myrouter.utilSingle, myrouter.utilSingleRes)
router.post('/utilMulterFile', myrouter.utilMulterFile, myrouter.utilMulterFileRes)


module.exports = router
