api/model/db.js --> 数据库连接
api/model/xxx.js --> 数据库模型

api/controller/xxx/index.js --> 数据返回
api/controller/xxx/xxx.js --> 数据模型方法扩展

api/common/xxx.js --> 公共方法